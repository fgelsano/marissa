<?php include 'header.php' ?>
	<div id="catering">
		<section class="main-banner" style="background-image: url('<?php echo get_template_directory_uri() ?>/assets/images/catering/eating-601578_1280.jpg')">
			<div class="overlay"></div>
			<div class="container">
				<div class="main-content">
					<h2>New</h2>
					<h2>Page</h2>
				</div>
				<div class="content-image">
					<img src="<?php echo get_template_directory_uri() ?>/assets/images/catering/icon-3.png">
				</div>
			</div>
		</section>		
<?php include 'footer.php' ?>